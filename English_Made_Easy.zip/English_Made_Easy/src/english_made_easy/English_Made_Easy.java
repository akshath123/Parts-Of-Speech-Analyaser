package english_made_easy;

import javax.swing.* ;
import java.sql.* ;
import java.awt.* ;
import java.awt.event.* ;

public class English_Made_Easy extends JFrame implements ActionListener{

    JLabel background, title  ;
    
    JButton login, signup, guest, exit ;
    
    English_Made_Easy()
    {
        super("Main Menu") ;
        
        setSize(500, 500) ;
        
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background4.jpg"))) ;
        add(background) ;
        
        background.setLayout(new BoxLayout(background,BoxLayout.Y_AXIS));
        
        background.add(Box.createVerticalStrut(50)) ;
        
        title = new JLabel("English Made Easy") ;
        title.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,40));
        title.setForeground(Color.white );
        
        login = new JButton("      Login      ") ;
        login.setFont(new Font("Serif",Font.BOLD,15)) ;
        login.setForeground(Color.black);
        login.addActionListener(this) ;
        login.setFocusPainted(false) ;
        
        signup = new JButton("      Sign up    ") ;
        signup.setFont(new Font("Serif",Font.BOLD,15));
        signup.setForeground(Color.black);
        signup.addActionListener(this) ;
        signup.setFocusPainted(false) ;
        
        guest = new JButton("       Guest      ") ;
        guest.setForeground(Color.black) ;
        guest.setFont(new Font("Serif",Font.BOLD,15));
        guest.addActionListener(this) ;
        guest.setFocusPainted(false) ;
        
        exit = new JButton("        Exit        ") ;
        exit.setForeground(Color.black) ;
        exit.setFont(new Font("Serif",Font.BOLD,15));
        exit.addActionListener(this) ;
        exit.setFocusPainted(false);
       
        background.add(Box.createVerticalStrut(50)) ;
        title.setAlignmentX(JComponent.CENTER_ALIGNMENT);
        background.add(title) ;
        
        background.add(Box.createVerticalStrut(40)) ;
        login.setAlignmentX(JComponent.CENTER_ALIGNMENT);
        background.add(login) ;
        
        background.add(Box.createVerticalStrut(15)) ;
        signup.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;
        background.add(signup) ;
        
        background.add(Box.createVerticalStrut(15)) ;
        guest.setAlignmentX(JComponent.CENTER_ALIGNMENT) ;
        background.add(guest) ;
        
        background.add(Box.createVerticalStrut(15)) ;
        exit.setAlignmentX(JComponent.CENTER_ALIGNMENT); 
        background.add(exit) ;
    }
    
    public void close_frame()
    {
        setVisible(false) ;
        dispose() ;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        JButton clicked = (JButton) ae.getSource() ;
        
        if( clicked == login )
        {
            close_frame() ;
            Login ob = new Login() ;
        }
        
        else if( clicked == signup )
        {
            close_frame() ;
            Sign_Up si = new Sign_Up() ;
        }
        
        else if( clicked == guest )
        {
            close_frame() ;
            Search ch = new Search(1) ;
        }
        
        else if( clicked == exit )
        {
            dispose() ;
            System.exit(0) ;
        }
    }
    
    public static void main(String[] args) {
        English_Made_Easy obj = new English_Made_Easy() ;
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        obj.setLocationRelativeTo(null);
        obj.setVisible(true);
    }
    
}

class Login extends JFrame implements ActionListener{
    
    JLabel welcome ,user , pass;
    JButton login, back ;
    JTextField username;
    
    Login()
    {
        change_path() ;
    }
    
    public void change_path()
    {
        Login ob = new Login(1) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null) ;
        ob.setVisible(true);
    }
    
    Login(int i)
    {
        super("Login") ;
        setSize(580,300) ;
        
        setLayout(new BorderLayout()) ;
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/background2.jpg"))) ;
        add(background) ;
       
        background.setLayout(null);
    
        welcome = new JLabel("Login") ;
        welcome.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,30)) ;
        welcome.setForeground(Color.black) ;
        welcome.setBounds(260, 30, 90, 40) ;
        
        user = new JLabel("Username: ") ;
        user.setBounds(120, 100, 120, 30) ;
        user.setForeground(Color.black) ;
        user.setFont(new Font("Serif",Font.BOLD,20)) ;
        
        username = new JTextField(30) ;
        username.addActionListener(this) ;
        username.setBounds(230, 105, 170, 20) ;
        
        login = new JButton("   NEXT   ") ;
        login.setBounds(325, 170, 90, 25);
        login.setForeground(Color.black );
        login.addActionListener(this) ;
        
        back = new JButton("   BACK   ") ;
        back.setBounds(215, 170, 90, 25);
        back.setForeground(Color.black) ;
        back.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent ae)
                {
                    dispose() ;
                    English_Made_Easy ob = new English_Made_Easy() ;
                    ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
                    ob.setLocationRelativeTo(null) ;
                    ob.setVisible(true) ;
                }
        }) ;
        
        background.add(welcome) ;        
        background.add(user) ;
        background.add(username) ;
        background.add(login) ;
        background.add(back) ;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        String login = username.getText() ;
        int flag = 1 ;
        
        try{
            
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/english","root","forgotpass1") ;           
            Statement stm = con.createStatement() ;
            String sql = "select Username from login_details" ;
            ResultSet rst = stm.executeQuery(sql) ;
            
            while( rst.next() )
            {
                String user1 = rst.getString("Username") ;                
                if( user1.equals(login) )
                {
                    dispose() ;
                    flag = 0 ;
                    new Password(login) ;
                    break ;
                }
                else 
                    flag = 1 ;
            }
            
            if(flag == 1)
            {
                System.out.println(flag); 
            JOptionPane.showMessageDialog(null,"Access Denied");
            username.setText("") ;
            }
         }catch(Exception e)
        {
            System.out.println(e) ;
        }
    }
}

