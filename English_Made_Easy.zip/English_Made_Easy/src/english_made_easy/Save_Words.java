
package english_made_easy;

import javax.swing.* ;
import java.awt.* ;
import java.awt.event.* ;

public class Save_Words extends JFrame{
    
    JComboBox word_list ;
    JButton save, back ;

    Save_Words(String[] words) {
        changePath(words) ;
        System.out.println(words[0]);
    }
    
    public void changePath(String[] words)
    {
        System.out.println(words[1]);
        Save_Words ob = new Save_Words(1,words) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null) ;
        ob.setVisible(true) ;
    }
    
    Save_Words(int i,String[] words)
    {
        super(" Save words ") ;
        setSize(500,500) ;
        
        setLayout(new BorderLayout()) ;
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/background4.jpg"))) ;
        add(background) ;
        
        background.setLayout(null) ;
        
        JLabel inst_part1 = new JLabel(" Select the words from the drop box ") ;
        JLabel inst_part2 = new JLabel(" and press save button ") ;
        inst_part1.setFont(new Font("Lucida Calligraphy",Font.BOLD,15)) ;
        inst_part1.setBounds(100,20,400,15) ;
        inst_part2.setFont(new Font("Lucida Calligraphy",Font.BOLD,15));
        inst_part2.setBounds(150,40,400,15);
        inst_part1.setForeground(Color.white);
        inst_part2.setForeground(Color.white) ;
        background.add(inst_part1) ;
        background.add(inst_part2) ;
        
        word_list = new JComboBox() ;
        for( int i1 = 0 ; i1 < words.length ; i1++ )
        {
            if( words[i1] == null )
            {
                break ;
            }
            word_list.addItem(words[i1]) ;
        }
        
        word_list.setBounds(200,200,90,25);
        background.add(word_list) ;
        
        save = new JButton("Save") ;
        save.setFont(new Font("Serif",Font.BOLD,20)) ;
        save.setForeground(Color.black) ;
        save.setBounds(250,400,90,25) ;
        
        back = new JButton("Back") ;
        back.setFont(new Font("Serif",Font.BOLD,20)) ;
        back.setForeground(Color.black) ;
        back.setBounds(150,400,90,25) ;
        back.addActionListener(new ActionListener(){   
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose() ;
                Search ob = new Search(0) ;
            }
        })  ;
        
        background.add(save) ;
        background.add(back) ;
    }
}
