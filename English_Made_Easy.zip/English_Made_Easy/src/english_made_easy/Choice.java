
package english_made_easy;

import java.awt.* ;
import javax.swing.* ;
import java.awt.event.* ;

public class Choice extends JFrame implements ActionListener{
    
    JButton search, view_history, back ;
    JLabel background, banner ;
    String wel_address = " Welcome to English made easy, enjoy :) " ;
    
    Choice()
    {
        change_path();
    }
    
    public void change_path()
    {
        Choice ch = new Choice(1) ;
        ch.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ch.setSize(400, 400) ;
        ch.setLocationRelativeTo(null);
    }
    
    Choice(int i)
    {
        super("Choice") ;
        setVisible(true) ;
        
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background4.jpg"))) ;
        
        background.setLayout(null) ;
        
        search = new JButton("      SEARCH      ") ;
        search.addActionListener(this) ;
        search.setBounds(110, 120, 160, 25) ;
        search.setForeground(Color.black) ;
        search.setFocusPainted(false) ;
        
        back = new JButton("     MAIN MENU    ") ;
        back.addActionListener(this) ;
        back.setBounds(110, 220, 160, 25) ;
        back.setForeground(Color.black) ; 
        back.setFocusPainted(false) ;
        
        view_history = new JButton(" VIEW SAVED WORDS ") ;
        view_history.addActionListener(this) ;
        view_history.setBounds(110, 170, 160, 25) ;
        view_history.setForeground(Color.black);
        view_history.setFocusPainted(false) ;
        
        banner = new JLabel(wel_address) ;
        banner.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,20)) ;
        banner.setForeground(Color.white) ;
        banner.setBounds(30, 300, 350, 25);
        
        add(background) ;
        background.add(search) ;
        background.add(back) ;
        background.add(view_history) ;
        background.add(banner) ;
    }
   
    @Override 
    public void actionPerformed(ActionEvent ae)
    {
        JButton b = (JButton) ae.getSource() ;
        
        if( b == search )
        {
            dispose() ;
            new Search(0) ;
        }
        else if( b == view_history )
        {
            dispose() ;
            View_Words ob = new View_Words() ;
        }
        else if( b == back )
        {
            dispose() ; 
            English_Made_Easy ob = new English_Made_Easy() ;
            ob.setLocationRelativeTo(null) ;
            ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ob.setVisible(true) ;
        }
    
    }
    
    
}
