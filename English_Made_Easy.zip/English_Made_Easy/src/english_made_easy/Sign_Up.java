package english_made_easy;

import java.awt.* ;
import java.awt.event.* ;
import javax.swing.* ;
import java.sql.* ;

public class Sign_Up extends JFrame implements ActionListener{
    
    JLabel background, username, confirm_pass, password ;
    JButton ok, back ;
    JTextField user ;
    JPasswordField pass, con_pass ;
    
    Sign_Up()
    {
        change_path() ;
    }
    
    public void change_path()
    {
        Sign_Up ob = new Sign_Up(1) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setLocationRelativeTo(null) ;
    }
    
    Sign_Up(int i)
    {
        super("Sign Up") ;
        setVisible(true) ;
         
        setSize(500, 500) ;
        
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background2.jpg"))) ;
        add(background) ;
        
        background.setLayout(null) ;
        
        username = new JLabel("Username:") ;
        username.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,20)) ;
        username.setForeground(Color.black);
        username.setBounds(90,50,150,25);
        
        user = new JTextField(20) ;
        user.setBounds(190, 50, 250, 25) ;
        
        password = new JLabel("Password:") ;
        password.setBounds(95, 130, 150, 25);
        password.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,20));
        password.setForeground(Color.black);
        
        pass = new JPasswordField(20) ;
        pass.setBounds(190,130,250,25);
        
        confirm_pass = new JLabel("Confirm Password:") ;
        confirm_pass.setBounds(20, 210, 180, 25);
        confirm_pass.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,20)) ;
        confirm_pass.setForeground(Color.black);
        
        con_pass = new JPasswordField(20) ;
        con_pass.setBounds(190,210,250,25) ;
        con_pass.addActionListener(new ActionListener(){
        
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                insert() ;
            }
    });
        
        ok = new JButton("OK") ;
        ok.setForeground(Color.black) ;
        ok.setBounds(270,300,90,25) ;
        ok.addActionListener( new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                insert() ;
            }
        }) ;
        
        back = new JButton("BACK") ;
        back.setForeground(Color.black) ;
        back.setBounds(130,300,90,25);
        back.addActionListener(this);
        
        background.add(username) ;
        background.add(user) ;
        background.add(password) ;
        background.add(pass) ;
        background.add(confirm_pass) ;
        background.add(con_pass) ;
        background.add(ok) ;
        background.add(back) ;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        JButton b = (JButton) ae.getSource() ;
        
        if( b == back )
        {
            close_frame() ;
            English_Made_Easy ob = new English_Made_Easy() ;
            ob.setLocationRelativeTo(null) ;
            ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
            ob.setVisible(true) ;
        }
    }
    
    public void close_frame() 
    {
        dispose() ;
    }
    
    public void insert()
    {
        int flag = 1 ;
        String u = user.getText() ;
        String p = pass.getText() ;
        String cp = con_pass.getText() ;
        
        try{
            
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/english","root","forgotpass1") ;
            Statement stm1 = con1.createStatement() ;
            String sql1 = "Select Username from login_details" ;
            ResultSet rs1 = stm1.executeQuery(sql1) ;
            
            while( rs1.next() )
            {
                if( u.equals(rs1.getString("Username"))) 
                {
                    JOptionPane.showMessageDialog(null,"Username already exits try again");
                    user.setText("");
                    pass.setText("") ;
                    con_pass.setText("");
                    flag = 0 ;
                    break ;
                }
                else 
                {
                        flag = 1 ;
                        }
            }
            
        }catch(SQLException e)
    {
        System.out.println(e) ;
    }
             
            if( flag == 1 )
            {
            if( p.equals(cp) )
            {
            try{
                System.out.println("ho") ;
                cp = cp.concat(u) ;
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/english","root","forgotpass1") ;
                Statement stm = con.createStatement() ;
                String sql = "insert into login_details values (NULL,'" +u +"','" +cp +"')" ;
                stm.executeUpdate(sql) ;
                
            }catch(SQLException e)
            {
                System.out.println() ;
            }
            close_frame() ;
            new Login() ;
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Mismatch of Passowrd");
            user.setText("");
            pass.setText("") ;
            con_pass.setText("");
        }
    }
}
}
