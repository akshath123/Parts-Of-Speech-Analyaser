
package english_made_easy;

import edu.stanford.nlp.tagger.maxent.MaxentTagger;
import java.awt.event.* ;
import java.sql.* ;
import java.awt.* ;
import javax.swing.* ;

public class Search extends JFrame implements ActionListener{
    
    JLabel background, search_label  ;
    JButton save_words, search, back ;
    JTextField input ;
    TextArea output ;
    String []words = new String[30] ;
    String []word_save = new String[30] ;
    
    Search(int y)
    {
        change_path(y) ;
    }
    
    public void change_path(int y)
    {
        Search ss = new Search(1,y) ;
        ss.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ss.setLocationRelativeTo(null);
    }
    
    Search(int i,int y)
    {
        super(" Search a word ") ;
        setVisible(true) ;
        setSize(600, 600);
             
        setLayout(new BorderLayout()) ;
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background4.jpg"))) ;
        
        // This is the component in which input will take place 
        input = new JTextField("Type here!!!!", 20) ;
        input.addActionListener(this) ;
        input.setBounds(30,50,400,27) ;
        input.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                output.setText("") ;
                meaning() ;
            }     
        }) ;
        
        // This is Button when pressed inisiates search action
        search = new JButton("SEARCH");
        search.setBounds(450,50,90,25) ;
        search.setForeground(Color.black) ;
        search.addActionListener(new ActionListener(){
            
            @Override 
            public void actionPerformed(ActionEvent ae)
            {
                output.setText("");
                meaning() ;
            }
        });
        
        // This component prints imformation on the TextArea 
        output = new TextArea(20,100) ;
        output.setBounds(30,100,510,400);
        output.setEditable(false) ;
        
        // This Button provides for storing imformation in database
        save_words = new JButton(" SAVE WORDS ") ;
        save_words.setBounds(210, 515, 160, 25);
        save_words.setForeground(Color.black) ;
        save_words.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                dispose() ;
                System.out.println("************************************");
                for( int i = 0 ; i < 9 ; i++ )
                System.out.println(word_save[i]) ; 
                Save_Words ob = new Save_Words(word_save) ;
            }
        }) ;
        
        back = new JButton("BACK") ;
        back.setBounds(30, 515, 90, 25) ;
        back.setForeground(Color.black) ;
        back.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
                {
                    if( y == 0 )
                {
                        dispose() ;
                        Choice ch = new Choice() ;
                }
                    else
                {       
                        dispose() ;
                        English_Made_Easy ob = new English_Made_Easy() ;
                        ob.setSize(500, 500) ;
                        ob.setVisible(true) ;
                        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
                        ob.setLocationRelativeTo(null) ;
                }
            }
        }) ;
        
        save_words.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
            
            }
        }) ;
        
        add(background) ;
        background.add(input) ;
        background.add(search) ;
        background.add(output) ;
        if( y == 0 )
        background.add(save_words) ;
        background.add(back) ;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       
    }
    
    public void meaning()
    {
        MaxentTagger tagger = new MaxentTagger("taggers/english-left3words-distsim.tagger") ;
        
        String []pos = new String[30] ;
        String sentence = input.getText() ;
        String word[] = new String[20] ;
        String S = " "  ;
        String tagged ;
        
        int i = 0, pos_index = 0 ;
        char c ;     

        for( String temp: sentence.split(S) )
        {
            word_save[i] = word[i] = temp ;
            System.out.println(word[i]) ;
            /*for(int k = 0 ; k < temp.length() ; k++ )
            {
                c = temp.charAt(k) ;
                if( c == '?' || c == '.' || c == ',' || c == '!' )
                {
                    System.out.println(temp) ;
                    word[i] = temp.substring(0,k-2) ;
                    break;
                }
            }*/
            i++ ;
            System.out.println(i) ;
        }
        
        /* ------------------------- DataBase code ----------------------------------*/
        
        //output.append("  \n" +" ----------------------------------------------- Meaning of the words ----------------------------------------------- \n\n") ;
        
     /*   try{
            
            Connection con2 = DriverManager.getConnection("jdbc:derby:S:\Databases\pbl","pbl","pbl") ;
            Statement stm2 = con2.createStatement() ;
            String sql2 = "Select * from MEAN" ;
            ResultSet rs2 = stm2.executeQuery(sql2) ;
            
            while(rs2.next())
            {
                String w = rs2.getString("WORD") ;
                String m = rs2.getString("MEANING") ;
                for(int k = 0 ; k < i ; k++ )
                {
                
                if( word[k].equals(w))
                {//*/
               //for(int k = 0 ; k < i ; k++ )
                //    output.append("   " +word[k] +"-\n\n") ;
       /*             output.append(" " +m +"\n\n");
                }
                }
            }
        }catch(SQLException e)
        {
            System.out.println(e) ;
        }//*/
        
        /*-------------------------- Parts of speech tagger -------------------------*/
        
        output.append("  " +"------------------------------------------------- Parts of Speech ---------------------------------------------------- \n\n\n") ;
        
        tagged = tagger.tagString(sentence) ;
        
        for( String temp: tagged.split(" "))
        {
            String t = temp ;
            if( !t.equals("to") )
            {
                for( String temp1: t.split("_") )
                {
                    pos[pos_index] = temp1 ;
                }
                pos_index++ ;
            }
            else
            {
                pos[pos_index++] = temp ;
            }
        }
       System.out.println(" The words are ");
    for( int x = 0 ; x < i ; x++ )
    {
        output.append("  " +word[x] +" - ") ;
        String parts_of_speech = "" ;
        if( pos[x].equals("CC"))
        {
            parts_of_speech = "Coordinating conjuction" ;
        }
        else if( pos[x].equals("CD"))
        {
            parts_of_speech = "Cardinal conjuction" ;
        }else if( pos[x].equals("DT"))
        {
            parts_of_speech = "Determinier" ;
        }else if( pos[x].equals("EX"))
        {
            parts_of_speech = "Existential there";
        }else if( pos[x].equals("FW"))
        {
            parts_of_speech = "Foreign word";
        }else if( pos[x].equals("IN"))
        {
            parts_of_speech = "Preposition or subordinating conjunction" ;
        }else if( pos[x].equals("JJ"))
        {
            parts_of_speech = "Adjective" ;
        }else if( pos[x].equals("JJR"))
        {
            parts_of_speech = "Adjective, comparative";
        }else if( pos[x].equals("JJS"))
        {
            parts_of_speech = "Adjective, superlative" ;
        }else if( pos[x].equals("LS"))
        {
            parts_of_speech = "List item maker" ;
        }else if( pos[x].equals("MD"))
        {
            parts_of_speech = "Modal" ;
        }else if( pos[x].equals("NN"))
        {
            parts_of_speech = "Noun, singular or mass" ;
        }else if( pos[x].equals("NNS"))
        {
            parts_of_speech = "Noun, plural";
        }else if( pos[x].equals("NNP"))
        {
            parts_of_speech = "Proper noun, singular" ;
        }else if( pos[x].equals("NNPS"))
        {
            parts_of_speech = "Proper noun, plural" ;
        }else if( pos[x].equals("PDT"))
        {
            parts_of_speech = "Predeterminer";
        }else if( pos[x].equals("POS"))
        {
            parts_of_speech = "Possessive ending" ;
        }else if( pos[x].equals("PRP"))
        {
            parts_of_speech = "Personal pronoun ";
        }else if( pos[x].equals("PRP$"))
        {
            parts_of_speech = "Possessive pronoun " ;
        }else if( pos[x].equals("RB"))
        {
            parts_of_speech = "Adverb" ;
        }else if( pos[x].equals("RBR"))
        {
            parts_of_speech = "Adverb, comparative";
        }else if( pos[x].equals("RBS"))
        {
            parts_of_speech = "Adverb, superlative" ;
        }else if( pos[x].equals("RP"))
        {
            parts_of_speech = "Particle" ;
        }
        else if( pos[x].equals("SYM"))
        {
            parts_of_speech = "Symbol" ;
        }
        
        else if( pos[x].equals("TO"))
        {
            parts_of_speech = "to" ;
        }
        
        else if( pos[x].equals("UH"))
        {
            parts_of_speech = "Interjection" ;
        }
        
        else if( pos[x].equals("VB"))
        {
            parts_of_speech = "Verb, base form " ;
        }
        
        else if( pos[x].equals("VBD"))
        {
            parts_of_speech = "Verb, past tense " ;
        }
        
        else if( pos[x].equals("VBG"))
        {
            parts_of_speech = "Verb, gerund or present participle " ;
        }
        
        else if( pos[x].equals("VBN"))
        {
            parts_of_speech = "Verb, past participle " ;
        }
        
        else if( pos[x].equals("VBP"))
        {
            parts_of_speech = "Verb, non­3rd person singular present " ;
        }
        
        else if( pos[x].equals("VBZ"))
        {
            parts_of_speech = "Verb, 3rd person singular present " ;
        }
        
        else if( pos[x].equals("WDT"))
        {
            parts_of_speech = "Wh­determiner " ;
        }
        
        else if( pos[x].equals("WP"))
        {
            parts_of_speech = "Wh­pronoun " ;
        }
        
        else if( pos[x].equals("WP$"))
        {
            parts_of_speech = "Possessive wh­pronoun " ;
        }
        
        else if( pos[x].equals("WRB"))
        {
            parts_of_speech = "Wh­adverb" ;
        }
        
        output.append("  " +parts_of_speech+".\n\n" );
    } 
        
    }
}
