
package english_made_easy;

import javax.swing.* ;
import java.awt.event.* ;
import java.awt.* ;
import java.sql.* ;

/**
 *
 * @author Akshath Varugeese
 */
public class Password extends JFrame implements ActionListener{
    
    JPasswordField password ;
    JLabel welcome, pass, background ;
    JButton login, back ;
    String user ;
    
    Password(String user)
    {
        change_path(user) ;
    }
    
    public void change_path(String user)
    {
        Password win = new Password(1,user) ;
        win.setLocationRelativeTo(null); 
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
    }
    
    Password(int i, String user)
    {
        super("Password") ;
        this.user = user ;
        setVisible(true) ;
        setSize(580, 300);
        
        setLayout(new BorderLayout()) ;
        
        background = new JLabel(new ImageIcon(getClass().getResource("/images/background4.jpg"))) ;
        
        background.setLayout(null) ;
        
        welcome = new JLabel(" Welcome, Please enter your password..") ;
        welcome.setFont(new Font("Serif",Font.BOLD|Font.ITALIC,30)) ;
        welcome.setForeground(Color.white) ;
        welcome.setBounds(30, 30, 560, 40) ;
        
        password = new JPasswordField(30) ;
        password.setBounds(230, 105, 170, 20) ;
         
        login = new JButton("   LOGIN   ") ;
        login.setBounds(290, 170, 90, 25);
        login.setForeground(Color.black );
        login.addActionListener(this) ;
        
        back = new JButton(" BACK ") ;
        back.setBounds(180, 170, 90, 25) ;
        back.setForeground(Color.black) ;
        back.addActionListener(this) ;
        
        pass = new JLabel("Password: ") ;
        pass.setBounds(120, 100, 120, 30) ;
        pass.setForeground(Color.black) ;
        pass.setFont(new Font("Serif",Font.BOLD,20)) ;
        
        add(background) ;
        background.add(welcome) ;
        background.add(pass) ;
        background.add(password) ;
        background.add(back) ;
        background.add(login) ;
    }
    
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        String p;
        int flag = 1 ;
        p = (String)password.getText();
        p = p.concat(user) ;
        JButton b = (JButton) ae.getSource() ;
        
        if( b == back )
        {
           flag = 0 ;
        }
        
        if( flag == 1  ) 
        {
            int flag1 = 0 ;
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/english","root","forgotpass1") ;
            Statement stm = con.createStatement() ;
            String sql = "select Password from login_details" ;
            ResultSet rs = stm.executeQuery(sql) ;
            
            while(rs.next())
            {
                if(p.equals(rs.getString("Password")))
                {
                    dispose() ;
                    flag1 = 0 ;
                    new Choice() ;
                    break ;
                }
                else
                {
                    flag1 = 1 ;
                }
            }    
            
            if(flag1 == 1)
            {
                JOptionPane.showMessageDialog(null,"Password Incorrect") ;
                    password.setText("") ;
            }
        }catch(SQLException e)
        {
            System.out.println(e) ;
        }
       }
        else if( flag == 0 )
        {
            dispose() ;
            new Login() ;
        }
    }
}
