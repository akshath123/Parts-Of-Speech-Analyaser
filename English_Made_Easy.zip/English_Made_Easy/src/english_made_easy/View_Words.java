
package english_made_easy;

import javax.swing.* ;
import java.awt.* ;
import java.awt.event.* ;
import java.io.* ;

public class View_Words extends JFrame{
    
    TextArea display ;
    JButton back ;
    
    View_Words()
    {
        change_Path() ;
    }
    
    public void change_Path()
    {
        View_Words ob = new View_Words(1) ;
        ob.setLocationRelativeTo(null) ;
        ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
        ob.setVisible(true) ;
    }
    
    public View_Words(int i) {
        super(" View Saved Words ") ;
        
        setSize(500,500) ;
        
        setLayout(new BorderLayout()) ;
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/images/background4.jpg"))) ;
        add(background) ;
            
        display = new TextArea(20,100) ;
        display.setBounds(20,20,445,370) ;
        display.setEditable(false) ;
        
        back = new JButton("Back") ;
        back.setFocusPainted(false) ;
        back.setForeground(Color.black) ;
        back.setBounds(200,400,90,25);
        back.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                dispose() ;
                Choice ob = new Choice() ;
            }
        }) ;
        
        background.add(display) ;
        background.add(back) ;
    }
    
}
